<?php
/* @var array|string|int|float|bool|object $args data
 * @var string $template_name template username
 */
?>
<div class="wbcr-content-section">
    <!-- ############################### -->
    <div class="wbcr-factory-page-group-header" style="margin:0">
        <strong>Wordpress Vulnerabilities</strong>
        <p>description</p>
    </div>
    <div class="wtitan-vulner-table-container wtitan-wp">
    </div>
    <!-- ############################### -->
    <div class="wbcr-factory-page-group-header" style="margin:0">
        <strong>Plugins Vulnerabilities</strong>
        <p>description</p>
    </div>
    <div class="wtitan-vulner-table-container wtitan-plugin">
    </div>
    <!-- ############################### -->
    <div class="wbcr-factory-page-group-header" style="margin:0">
        <strong>Themes Vulnerabilities</strong>
        <p>description</p>
    </div>
    <div class="wtitan-vulner-table-container wtitan-theme">
    </div>
    <!-- ############################### -->
</div>
