<?php exit('Access denied'); __halt_compiler(); ?>
******************************************************************
This file is used by the Wordfence Web Application Firewall. Read 
more at https://docs.wordfence.com/en/Web_Application_Firewall_FAQ
******************************************************************
a:2:{s:20:"whitelistedURLParams";N;s:4:"cron";a:3:{i:0;O:24:"wfWAFCronFetchRulesEvent":1:{s:11:" * fireTime";i:1616361520;}i:1;O:25:"wfWAFCronFetchIPListEvent":1:{s:11:" * fireTime";i:1616445281;}i:2;O:36:"wfWAFCronFetchBlacklistPrefixesEvent":1:{s:11:" * fireTime";i:1616366081;}}}