<?php


namespace WBCR\Titan\Client\Response\Method;

use WBCR\Titan\Client\Loader;

/**
 * Class UrlCheckerCreate
 * @package WBCR\Titan\Client\Response\Method
 *
 * @author Alexander Gorenkov <g.a.androidjc2@ya.ru>
 */
class UrlCheckerCreate extends Loader {
	/**
	 * UrlCheckerCreate constructor.
	 *
	 * @param array $urls
	 */
	public function __construct($urls) {
	}
}