# ConvertKit i18n #

  To help translate, review, or improve a translation, join our Translations Community at
  https://translate.wordpress.org/projects/wp-plugins/convertkit

  More info at https://make.wordpress.org/polyglots/
