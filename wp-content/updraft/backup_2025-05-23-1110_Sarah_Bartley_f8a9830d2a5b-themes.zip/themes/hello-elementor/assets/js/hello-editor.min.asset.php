<?php return array('dependencies' => array(), 'version' => 'edeacf99ffeb0c9a8fa7');
