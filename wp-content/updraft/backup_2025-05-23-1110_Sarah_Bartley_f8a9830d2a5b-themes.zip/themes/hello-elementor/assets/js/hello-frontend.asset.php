<?php return array('dependencies' => array(), 'version' => '1b7e153396e630f0bee8');
