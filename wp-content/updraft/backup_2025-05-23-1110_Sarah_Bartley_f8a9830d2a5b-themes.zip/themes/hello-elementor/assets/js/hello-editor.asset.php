<?php return array('dependencies' => array(), 'version' => 'adae8bb641e97e72db73');
