<?php return array('dependencies' => array('react', 'react-dom', 'wp-api-fetch', 'wp-i18n'), 'version' => 'a1045108caecb49c12f5');
