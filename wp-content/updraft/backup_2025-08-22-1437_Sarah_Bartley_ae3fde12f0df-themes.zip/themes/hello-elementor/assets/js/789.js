"use strict";
(self["webpackChunkelementor_hello_theme"] = self["webpackChunkelementor_hello_theme"] || []).push([[789],{

/***/ 2789:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ TextIcon)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1609);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _elementor_ui_SvgIcon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5422);



const TextIcon = react__WEBPACK_IMPORTED_MODULE_0__.forwardRef((props, ref) => {
  return /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement(_elementor_ui_SvgIcon__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A, { viewBox: "0 0 24 24", ...props, ref }, /* @__PURE__ */ react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", { d: "M4.25 5C4.25 4.58579 4.58579 4.25 5 4.25H19C19.4142 4.25 19.75 4.58579 19.75 5V7C19.75 7.41421 19.4142 7.75 19 7.75C18.5858 7.75 18.25 7.41421 18.25 7V5.75H12.75V18.25H14C14.4142 18.25 14.75 18.5858 14.75 19C14.75 19.4142 14.4142 19.75 14 19.75H10C9.58579 19.75 9.25 19.4142 9.25 19C9.25 18.5858 9.58579 18.25 10 18.25H11.25V5.75H5.75V7C5.75 7.41421 5.41421 7.75 5 7.75C4.58579 7.75 4.25 7.41421 4.25 7V5Z" }));
});


//# sourceMappingURL=index.esm.js.map


/***/ })

}]);