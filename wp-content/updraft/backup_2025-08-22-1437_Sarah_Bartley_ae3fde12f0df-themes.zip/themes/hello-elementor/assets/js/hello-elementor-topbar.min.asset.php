<?php return array('dependencies' => array('react', 'react-dom', 'wp-i18n'), 'version' => '4808e112242e166842d3');
