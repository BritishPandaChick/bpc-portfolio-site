<?php return array('dependencies' => array(), 'version' => '29d3ef9742e2e1da326c');
