<?php return array('dependencies' => array(), 'version' => 'aad983901f10bf7e4e52');
