<?php


namespace WBCR\Titan\Client\Request;

/**
 * Class Request
 * @package WBCR\Titan\Client\Entity
 *
 * @author Alexander Gorenkov <g.a.androidjc2@ya.ru>
 */
abstract class Request {

}